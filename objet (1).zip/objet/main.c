#include <stdio.h>
#include "SDL/SDL.h"
#include <string.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
  #include <time.h> 
  #include <unistd.h>

int main()
{
    SDL_Surface *ecran =NULL;
    SDL_Surface *objet=NULL,*objet2=NULL;
    SDL_Rect positionecran,positionobjet;
  
    int continuer =1;
 
   

    SDL_Event event;

    objet=IMG_Load("objet.png");
    objet2=IMG_Load("objet2.png");
   

    positionobjet.x=400;
    positionobjet.y=0;
    SDL_Init(SDL_INIT_VIDEO);
    ecran = SDL_SetVideoMode(900, 600, 32, SDL_HWSURFACE );



    while (continuer)
    {
		
    
	SDL_FillRect(ecran,NULL,SDL_MapRGB(ecran->format, 255, 255, 255));

	 SDL_PollEvent(&event);
	if (positionobjet.y<446){
		SDL_BlitSurface(objet,NULL,ecran,&positionobjet);
		positionobjet.y=positionobjet.y+1;
}
	else 
	SDL_BlitSurface(objet2,NULL,ecran,&positionobjet);
	SDL_Flip(ecran);
       switch (event.type)
        {
        case SDL_QUIT:
            continuer=0;
            break;
	        case SDL_KEYDOWN:
            switch (event.key.keysym.sym)
            {
            case SDLK_UP:
               positionobjet.y=0;
                break;
            }
	
	}
    }
    SDL_FreeSurface(objet);
 
    return 0;
}
