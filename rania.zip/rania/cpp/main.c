#include <stdio.h>
#include <stdlib.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_ttf.h>
#include"background.h"
#include"perso.h"

//#include"main.h"

void main (){
	SDL_Surface *ecran =NULL;
	hero evan ;
	int continuer =1;
	SDL_Init(SDL_INIT_VIDEO);
	initialiser_evan(&evan);
	evan.farm=0;
	background bckg;
	SDL_Event event;
	int c;
	int x;
	int a;
	ecran = SDL_SetVideoMode(1200, 600, 32, SDL_HWSURFACE | SDL_DOUBLEBUF);
	initialiser_background(&bckg);
	while(continuer){
		SDL_FillRect(ecran, NULL, SDL_MapRGB(ecran->format, 0, 0, 0));
		evan.mouvment=mouvment(evan,&event);
		afficher_background(bckg,ecran);
		afficher_evan(evan,ecran);
		SDL_Flip(ecran);
		c=collision_Parfaite(bckg.calque_background,evan.afficher_hero[evan.farm],evan.pos_hero2,bckg.pos_background2);
printf("%d  cc\n",c);
}
}



