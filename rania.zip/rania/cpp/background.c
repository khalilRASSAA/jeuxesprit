#include <stdio.h>
#include <stdlib.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_ttf.h>
#include"background.h"
void initialiser_background(background *bckg){


	bckg->calque_background=NULL;
	bckg->calque_background=IMG_Load("calquebackground.png");

	bckg->afficher_background=NULL;
	bckg->afficher_background=IMG_Load("background.jpg");
	bckg->pos_background.x=0;
	bckg->pos_background.y=0;
	bckg->pos_background2.x=0;
	bckg->pos_background2.y=0;
	bckg->pos_background2.h=600;
	bckg->pos_background2.w=1200;
}
void afficher_background(background bckg,SDL_Surface *ecran){
	
	SDL_BlitSurface(bckg.afficher_background,&(bckg.pos_background2),ecran,&(bckg.pos_background));
	//printf("%d %d %d %d \n", bckg->pos_background2.x,bckg->pos_background2.y,bckg->pos_background2.h,bckg->pos_background2.w);
	//SDL_Flip(ecran);

}

SDL_Color GetPixel(SDL_Surface *surface,int x,int y)
{
	SDL_Color color ;
	Uint32 col = 0 ;
	char* pPosition = ( char* ) surface->pixels ;
	pPosition += ( surface->pitch * y ) ;
	pPosition += ( surface->format->BytesPerPixel * x ) ;
	memcpy ( &col , pPosition , surface->format->BytesPerPixel ) ;
	SDL_GetRGB ( col , surface->format , &color.r , &color.g , &color.b ) ;
	return ( color ) ;
}



int collision_Parfaite(SDL_Surface *calque,SDL_Surface *perso,SDL_Rect posperso,SDL_Rect posmap)
{
  	SDL_Color col,col2,col22,col1;
	col=GetPixel(calque,posperso.x+100+posmap.x,posperso.y+280);
	col2=GetPixel(calque,posperso.x+50+posmap.x,posperso.y+250);
	col22=GetPixel(calque,posperso.x+100+posmap.x,posperso.y+200);
	col1=GetPixel(calque,posperso.x+100+posmap.x,posperso.y+240);

if ((col.r==0)&&(col.b==0)&&(col.g==255))
  return 1;//7ofra
else if ((col22.r==0)&&(col22.b==0)&&(col22.g==0))
  return 2;//obstacle
else if ((col1.r==0)&&(col1.b==255)&&(col1.g==0))
  return 1;//choukakbira
else if ((col22.r==255)&&(col22.b==0)&&(col22.g==0))
  return 3;//door enigme
else if ((col2.r==0)&&(col2.b==0)&&(col2.g==0))
 return 10;//9a3
else
{
	return 0;
}
}
